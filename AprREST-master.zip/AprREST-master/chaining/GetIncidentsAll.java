package chaining;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.authentication.BasicAuthScheme;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class GetIncidentsAll extends BaseAssured{
	
	@Test
	public void getAllIncidents() {
				
		// Request - Get send
		Response response = requestSpec
				.get();
		
		// Response - Read or Validate
		JsonPath responseJson = response.jsonPath();
		
		sys_id = responseJson.getList("result.sys_id").get(0).toString();
		System.out.println(sys_id);
	}
	

}
