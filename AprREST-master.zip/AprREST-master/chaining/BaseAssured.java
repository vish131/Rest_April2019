package chaining;

import org.testng.annotations.BeforeSuite;

import io.restassured.RestAssured;
import io.restassured.authentication.BasicAuthScheme;
import io.restassured.specification.RequestSpecification;

public class BaseAssured {
	
	public static String sys_id;
	public static RequestSpecification requestSpec;

	@BeforeSuite
	public void setValues() {

		//1) URL
		RestAssured.baseURI = "https://dev38211.service-now.com/api/now/table/incident";		
		//2) Auth
		BasicAuthScheme basic = new BasicAuthScheme();
		basic.setUserName("admin");
		basic.setPassword("Tuna@123");
		RestAssured.authentication = basic;
		
		requestSpec = RestAssured
		.given()
		.log()
		.all();
	}

}
