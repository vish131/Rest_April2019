package chaining;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.authentication.BasicAuthScheme;
import io.restassured.response.Response;

public class DeleteIncident extends BaseAssured {
	
	@Test(dependsOnMethods="chaining.GetIncidentsAll.getAllIncidents")
	public void deleteIncident() {
		
		// Request - Get send
		Response response = requestSpec
				.delete("/"+sys_id);
		
		// Response - Read or Validate
		response.prettyPrint();
		
		// Get the return count
		long time = response.getTime();
		System.out.println(time);
		
		// Status
		System.out.println(response.getStatusCode());
		
		
	}
	

}
