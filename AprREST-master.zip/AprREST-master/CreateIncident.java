package basics;

import java.io.File;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.authentication.BasicAuthScheme;
import io.restassured.response.Response;

public class CreateIncident {
	
	@DataProvider(name="getData"/*, parallel=true, indices= {1}*/)
	public String[] getData(){
		
		String[] data = new String[2];
		data[0] = "data.json";
		data[1] = "data2.json";		
		return data;
		
	}

	@Test(dataProvider="getData")
	public void getAllIncidents(String filePath) {
		
		//1) URL
		RestAssured.baseURI = "https://dev38211.service-now.com/api/now/table/incident";		
		//2) Auth
		BasicAuthScheme basic = new BasicAuthScheme();
		basic.setUserName("admin");
		basic.setPassword("Tuna@123");
		RestAssured.authentication = basic;
		
		// Create a file Object
		File file = new File("./data/"+filePath);		
		// Request - Get send
		Response response = RestAssured
				.given()
				.contentType("application/json")
				.body(file)
				.post();
		
		// Response - Read or Validate
		response.prettyPrint();
		
		// What is my status code
		int statusCode = response.statusCode();
		System.out.println(statusCode);
		
		String statusLine = response.statusLine();
		System.out.println(statusLine);
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
