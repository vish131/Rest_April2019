package railways;

import java.util.List;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class C03_FindSeatAvailabilityInTrainWithChairCar extends BaseAssured{
	
	@Test(dependsOnMethods="railways.C02_FindTrainWithChairCar.findAllTrainsWithCC")
	public void findSeatAvailability() {
		
		for (String eachTrain : trainsWithChairCar) {
			
			// Request - Get send
			Response response = RestAssured
					.given()
					.log()
					.all()
					.get("https://api.railwayapi.com/v2/check-seat/train/"+eachTrain+"/source/MS/dest/TPJ/date/15-04-2019/pref/CC/quota/GN/apikey/e5vdz0roz3");
			
			response.prettyPrint();
			
			JsonPath jsonResponse = response.jsonPath();
			
			List<String> classes = jsonResponse.getList("train.classes.code");
			List<String> availability = jsonResponse.getList("train.classes.available");

			for (int i = 0; i < classes.size(); i++) {
				if(classes.get(i).equals("CC") && availability.get(i).equals("Y")) {
					System.out.println("Hurray!! This train have the 'CC' and have seats "+eachTrain);
					break;
				}
			}
			
		}
		
		
		
	}
	

}
