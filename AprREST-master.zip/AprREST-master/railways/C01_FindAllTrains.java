package railways;


import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class C01_FindAllTrains extends BaseAssured{
	
	@Test
	public void findAllTrains() {
		
		RestAssured.baseURI = "https://api.railwayapi.com/v2/between/source/MS/dest/TPJ/date/15-04-2019/apikey/e5vdz0roz3";
				
		// Request - Get send
		Response response = RestAssured
				.given()
				.log()
				.all()
				.get();
		
		response.prettyPrint();
		
		JsonPath jsonResponse = response.jsonPath();
		
		trainsList = jsonResponse.getList("trains.number");
		for (String trainNumber : trainsList) {
			System.out.println(trainNumber);
		}
		
		
	}
	

}
