package railways;

import java.util.List;

public class BaseAssured {
	
	public static List<String> trainsList ;
	public static List<String> trainsWithChairCar;

	

}
