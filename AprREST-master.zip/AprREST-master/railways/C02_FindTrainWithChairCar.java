package railways;

import java.util.ArrayList;
import java.util.List;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class C02_FindTrainWithChairCar extends BaseAssured{
	
	@Test(dependsOnMethods="railways.C01_FindAllTrains.findAllTrains")
	public void findAllTrainsWithCC() {
		
		for (String eachTrain : trainsList) {
			
			// Request - Get send
			Response response = RestAssured
					.given()
					.log()
					.all()
					.get("https://api.railwayapi.com/v2/name-number/train/"+eachTrain+"/apikey/e5vdz0roz3");
			
			response.prettyPrint();
			
			JsonPath jsonResponse = response.jsonPath();
			
			List<String> classes = jsonResponse.getList("train.classes.code");
			List<String> availability = jsonResponse.getList("train.classes.available");
			trainsWithChairCar = new ArrayList<String>();

			for (int i = 0; i < classes.size(); i++) {
				if(classes.get(i).equals("CC") && availability.get(i).equals("Y")) {
					System.out.println("The trains have the CC "+eachTrain);
					trainsWithChairCar.add(eachTrain);
					break;
				}
			}
			
		}
		
		
		
	}
	

}
