package basics;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.authentication.BasicAuthScheme;
import io.restassured.http.ContentType;
import io.restassured.http.Header;
import io.restassured.http.Headers;
import io.restassured.response.Response;

public class UpdateIncident {

	@Test
	public void getAllIncidents() {

		//1) URL
		RestAssured.baseURI = "https://dev38211.service-now.com/api/now/table/incident";

		//2) Auth
		BasicAuthScheme basic = new BasicAuthScheme();
		basic.setUserName("admin");
		basic.setPassword("Tuna@123");
		RestAssured.authentication = basic;

		// Create a file Object
		File file = new File("./data/data.json");	
		
		// Create Headers
		Header contentType = new Header("Content-Type", "application/json");
		Header accept = new Header("Accept", "application/xml");
		
		List<Header> allHeaders = new ArrayList<Header>();
		allHeaders.add(contentType);
		allHeaders.add(accept);

		Headers headers = new Headers(allHeaders);

		// Request - Get send
		Response response = RestAssured
				.given()
				/*.contentType("application/json")
				.accept(ContentType.XML)*/
				.headers(headers)
				/*.header(new Header("", ""))*/
				.log()
				.all()
				.body(file)
				.put("/ee5c2e950f70330030f5cd8ce1050e18");

		// Response - Read or Validate
		response.prettyPrint();

		// Get the return count
		long time = response.getTime();
		System.out.println(time);


	}


}
