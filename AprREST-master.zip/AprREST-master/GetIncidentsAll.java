package basics;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.authentication.BasicAuthScheme;
import io.restassured.response.Response;

public class GetIncidentsAll {
	
	@Test
	public void getAllIncidents() {
		
		//1) URL
		RestAssured.baseURI = "https://dev38211.service-now.com/api/now/table/incident";
		
		//2) Auth
		BasicAuthScheme basic = new BasicAuthScheme();
		basic.setUserName("admin");
		basic.setPassword("Tuna@123");
		RestAssured.authentication = basic;
		
		// Request - Get send
		Response response = RestAssured.get();
		
		// Response - Read or Validate
		response.prettyPrint();
		
		// Get the return count
		//response.
		
		
	}
	

}
