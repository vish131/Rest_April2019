package basics;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.authentication.BasicAuthScheme;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class GetIncidentsAll_OnlyNumbers {
	
	@Test
	public void getAllIncidents() {
		
		//1) URL
		RestAssured.baseURI = "https://dev38211.service-now.com/api/now/table/incident";
		
		//2) Auth
		BasicAuthScheme basic = new BasicAuthScheme();
		basic.setUserName("admin");
		basic.setPassword("Tuna@123");
		RestAssured.authentication = basic;
		
		//2) Create Request Parameter Map
		Map<String, String> parametersMap = new HashMap<String, String>();
		parametersMap.put("sysparm_fields", "number,sys_id");
		parametersMap.put("priority", "1");
		
		// Request - Get send
		Response response = RestAssured
				.given()
				/*.param("sysparm_fields", "number,sys_id")
				.param("priority", "1")*/
				.params(parametersMap)
				.get();
		
		// Response - Read or Validate
		response.prettyPrint();
		
		
		JsonPath jsonResponse = response.jsonPath();
		System.out.println("****************************************");
		List<String> allNumbers = jsonResponse.getList("result.number");
		for (String eachNumber : allNumbers) {
			System.out.println(eachNumber);
		}
		
		System.out.println(allNumbers.size());
		
	}
	

}
